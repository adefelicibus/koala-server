void fatal_error(const char *__restrict __message);
void display_msg(const char *__restrict __message);
