
int get_pid();
void set_current_working_directory(char *path);
void delete_file(const char *path, const char *filename);

static void check_path(char *path);

