#ifndef OLD_VECTOR_TYPES_H
#define OLD_VECTOR_TYPES_H

typedef struct sown_vector{
	double x;
	double y;
	double z;
}own_vector_t;

typedef struct sown_vector_long{
	long double x;
	long double y;
	long double z;
}own_vector_long_t;

#endif
