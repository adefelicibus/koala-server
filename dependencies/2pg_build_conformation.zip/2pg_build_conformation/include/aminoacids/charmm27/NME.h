topol_residue_atoms_t residue_atoms_NME_C_Terminal [] = {
                                                {atmN,  "N","N",-0.41570},
                                                {atmCH3, "CH3","CT",0.27190},
                                                {atmH, "H","H",-0.14900},
                                        		{atmHH31,"HH31","H1",0.09760},
                                        		{atmHH32,"HH32","H1",0.09760},
                                        		{atmHH33,"HH33","H1",0.09760}
                                           };