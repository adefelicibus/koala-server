#ifndef OLD_MATH_OWNER_H
#define OLD_MATH_OWNER_H

float degree2radians(const float *degree);
float radians2degree(const float *radians);
float radians2degree_double(const double *radians);

#endif
