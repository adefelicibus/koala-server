Clazz.declarePackage ("J.adapter.readers.xtal");
Clazz.load (["J.adapter.readers.xtal.VaspPoscarReader"], "J.adapter.readers.xtal.VaspChgcarReader", null, function () {
c$ = Clazz.declareType (J.adapter.readers.xtal, "VaspChgcarReader", J.adapter.readers.xtal.VaspPoscarReader);
});
