Clazz.declarePackage ("JU");
Clazz.load (["java.lang.Enum"], "JU.Encoding", null, function () {
c$ = Clazz.declareType (JU, "Encoding", Enum);
Clazz.defineEnumConstant (c$, "NONE", 0, []);
Clazz.defineEnumConstant (c$, "UTF8", 1, []);
Clazz.defineEnumConstant (c$, "UTF_16BE", 2, []);
Clazz.defineEnumConstant (c$, "UTF_16LE", 3, []);
Clazz.defineEnumConstant (c$, "UTF_32BE", 4, []);
Clazz.defineEnumConstant (c$, "UTF_32LE", 5, []);
});
